#!/bin/bash

# executable name
exec=compile

for value in {1..27}
do
    echo __________________
    echo file: test/testcase$value.txt
    echo __________________
    ./$exec test/testcase$value.txt
    echo
done