#!/bin/bash

# executable name
exec=compile

for value in {1..19}
do
    echo __________________
    echo file: test/parserTest$value.txt
    echo __________________
    ./compile test/parserTest$value.txt -l -a -v 
    echo
done